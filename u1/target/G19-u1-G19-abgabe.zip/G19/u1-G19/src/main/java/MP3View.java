import javafx.scene.layout.BorderPane;


/**
 * Da diese Version mit Hilfe von FXML programmiert wurde ist diese Klasse leer.
 * Die FXML Datei übernimmt ihren Part und der Controller ebenfalls etwas
 *  => FXML enthält Daten, Logik & Verweise auf Handler etc
 *  => Controller enthält Verweise auf FXML-Elemente und Implementation Handler
 */

public class MP3View extends BorderPane {

    public MP3View() {
    }

}
